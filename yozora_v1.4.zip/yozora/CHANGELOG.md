# Changelog

## 1.4.0
- New GUI: tabs MODS / SETTINGS / COSMETICS / CONFIGS
- 75 modules in a card style
- Cosmetics: capes, wings, hats, pets
- FPS boost pipeline: entity culling, particle limiter, caches
- Themes with blur radius
- Sakura icon
