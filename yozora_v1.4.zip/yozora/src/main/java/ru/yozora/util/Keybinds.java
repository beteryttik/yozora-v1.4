package ru.yozora.util;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;
import ru.yozora.Yozora;

public class Keybinds {
    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (org.lwjgl.glfw.GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS) {
                client.setScreen(new ru.yozora.gui.ClickGuiScreen());
                break;
            }
        });
    }
}
