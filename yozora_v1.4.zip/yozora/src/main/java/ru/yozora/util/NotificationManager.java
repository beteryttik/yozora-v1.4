package ru.yozora.util;

import java.util.ArrayDeque;
import java.util.Deque;

public class NotificationManager {
    public record Notification(String title, String body, long born) {}
    private final Deque<Notification> queue = new ArrayDeque<>();

    public void push(String title, String body) {
        queue.addLast(new Notification(title, body, System.currentTimeMillis()));
        if (queue.size() > 8) queue.removeFirst();
    }

    public Deque<Notification> active() {
        return queue;
    }
}
