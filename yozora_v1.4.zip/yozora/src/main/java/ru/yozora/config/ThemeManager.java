package ru.yozora.config;

import java.util.ArrayList;
import java.util.List;
import ru.yozora.gui.theme.YozoraTheme;
import ru.yozora.gui.theme.ThemePresets;

public class ThemeManager {
    private static final List<String> PRESETS = List.of("Lunar Blue", "Sakura Pink", "Midnight Neon", "Forest");
    private YozoraTheme current = ThemePresets.byName("Sakura Pink");

    public void loadThemes() {
        // presets are registered statically; custom themes load from config/themes
    }

    public YozoraTheme current() { return current; }

    public void select(String name) {
        current = ThemePresets.byName(name);
    }

    public List<String> presets() { return PRESETS; }
}
