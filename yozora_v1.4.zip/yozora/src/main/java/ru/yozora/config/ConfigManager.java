package ru.yozora.config;

import java.util.ArrayList;
import java.util.List;

public class ConfigManager {
    public record ConfigEntry(String name, String owner, String timestamp, double sizeKb, long lastModified, boolean active) {
        public String agoText() {
            long diff = System.currentTimeMillis() - lastModified;
            long min = diff / 60000;
            if (min < 60) return min + " minutes ago";
            if (min < 1440) return (min / 60) + " hours ago";
            return (min / 1440) + " days ago";
        }
    }

    private final List<ConfigEntry> entries = new ArrayList<>();

    public void loadDefault() {
        entries.add(new ConfigEntry("default", "Yozora", "23.10 15:15", 39.1, System.currentTimeMillis() - 17L * 86400000, true));
    }

    public List<ConfigEntry> all() { return entries; }
}
