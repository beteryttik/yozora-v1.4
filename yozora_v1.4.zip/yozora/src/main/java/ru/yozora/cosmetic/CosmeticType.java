package ru.yozora.cosmetic;

public enum CosmeticType {
    ALL, WINGS, CAPES, HATS, PETS
}
