package ru.yozora.cosmetic;

public record Cosmetic(String id, String name, CosmeticType type, String description,
                       net.minecraft.util.Identifier texture,
                       boolean hideElytra, float motionDefault) {
}
