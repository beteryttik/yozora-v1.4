package ru.yozora.cosmetic;

import java.util.ArrayList;
import java.util.List;

public class CosmeticManager {
    private final List<Cosmetic> cosmetics = new ArrayList<>();
    private Cosmetic selected;

    public void load() {
        cosmetics.addAll(ru.yozora.cosmetic.CosmeticRegistry.all());
        selected = cosmetics.stream().filter(c -> c.id().equals("yozora_cape_01")).findFirst().orElse(null);
    }

    public List<Cosmetic> filtered(CosmeticType type) {
        List<Cosmetic> out = new ArrayList<>();
        for (Cosmetic c : cosmetics) {
            if (type == CosmeticType.ALL || c.type() == type) out.add(c);
        }
        return out;
    }

    public int count() { return cosmetics.size(); }
    public Cosmetic selected() { return selected; }
    public void select(Cosmetic c) { selected = c; }
    public void clearSelection() { selected = null; }
}
