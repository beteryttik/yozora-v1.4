package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * Blur post-processor hook
 */
@Mixin(net.minecraft.client.gui.DrawContext.class)
public class DrawContextMixin {
    @Inject(method = "draw", at = @At("HEAD"))
    private void yozora$blur(CallbackInfo ci) {
        Yozora.themes().current().drawBlur(null, 0, 0, 0);
    }
}
