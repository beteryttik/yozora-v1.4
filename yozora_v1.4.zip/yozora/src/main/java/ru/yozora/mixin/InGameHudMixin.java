package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * HUD elements render hook
 */
@Mixin(net.minecraft.client.gui.hud.InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void yozora$hud(net.minecraft.client.gui.DrawContext ctx, float delta, CallbackInfo ci) {
        Yozora.hud().renderAll(ctx, delta);
    }
}
