package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * Entity culling
 */
@Mixin(net.minecraft.client.render.WorldRenderer.class)
public class WorldRendererMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void yozora$cull(net.minecraft.client.render.RenderTickCounter counter, CallbackInfo ci) {
        Yozora.fpsBooster().prepareFrame();
    }
}
