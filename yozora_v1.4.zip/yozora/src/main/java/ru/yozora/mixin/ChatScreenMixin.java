package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * Chat time and filter
 */
@Mixin(net.minecraft.client.gui.screen.ChatScreen.class)
public class ChatScreenMixin {
    @Inject(method = "sendMessage", at = @At("HEAD"), cancellable = true)
    private void yozora$chat(String message, boolean toHud, CallbackInfo ci) {
        if (Yozora.chat().shouldBlock(message)) ci.cancel();
    }
}
