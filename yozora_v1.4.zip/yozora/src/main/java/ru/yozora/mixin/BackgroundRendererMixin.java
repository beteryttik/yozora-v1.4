package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * Custom sky color
 */
@Mixin(net.minecraft.client.render.BackgroundRenderer.class)
public class BackgroundRendererMixin {
    @ModifyReturnValue(method = "applyFog", at = @At("RETURN"))
    private void yozora$skyColor(...) {}
}
