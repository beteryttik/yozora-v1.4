package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * Faster lighting updates
 */
@Mixin(net.minecraft.client.render.LightmapTextureManager.class)
public class LightmapTextureManagerMixin {
    @Inject(method = "update", at = @At("HEAD"), cancellable = true)
    private void yozora$lightUpdate(CallbackInfo ci) {
        if (Yozora.fpsBooster().lightDirty()) {
            ci.cancel();
        } else {
            Yozora.fpsBooster().markLightRendered();
        }
    }
}
