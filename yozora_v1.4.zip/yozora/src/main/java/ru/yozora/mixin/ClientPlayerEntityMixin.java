package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * SafeWalk and autosprint hooks
 */
@Mixin(net.minecraft.client.network.ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {
    @Inject(method = "isSprinting", at = @At("HEAD"), cancellable = true)
    private void yozora$sprint(CallbackInfoReturnable<Boolean> cir) {
        if (Yozora.modules().byName("autosprint").map(Module::isEnabled).orElse(false)) cir.setReturnValue(true);
    }
}
