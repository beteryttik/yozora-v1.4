package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * Custom main menu
 */
@Mixin(net.minecraft.client.gui.screen.TitleScreen.class)
public class TitleScreenMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void yozora$menu(net.minecraft.client.gui.DrawContext ctx, int mx, int my, float delta, CallbackInfo ci) {
        Yozora.gui().renderCustomMenu(ctx, mx, my, delta, ci);
        ci.cancel();
    }
}
