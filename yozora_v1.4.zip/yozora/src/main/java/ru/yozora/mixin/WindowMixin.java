package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * GUI scale control
 */
@Mixin(net.minecraft.client.util.Window.class)
public class WindowMixin {
    @ModifyReturnValue(method = "getScaleFactor", at = @At("RETURN"))
    private double yozora$guiScale(double original) {
        return original * Yozora.themes().current().guiScale();
    }
}
