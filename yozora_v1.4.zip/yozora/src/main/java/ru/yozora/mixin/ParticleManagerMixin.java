package ru.yozora.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.MinecraftClient;
import ru.yozora.Yozora;

/**
 * Particle limiter
 */
@Mixin(net.minecraft.client.particle.ParticleManager.class)
public class ParticleManagerMixin {
    @Inject(method = "addParticle", at = @At("HEAD"), cancellable = true)
    private void yozora$limitParticles(net.minecraft.client.particle.Particle particle, CallbackInfo ci) {
        if (!Yozora.fpsBooster().particleBudget()) ci.cancel();
    }
}
