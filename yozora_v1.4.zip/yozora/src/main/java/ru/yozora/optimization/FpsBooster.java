package ru.yozora.optimization;

import ru.yozora.Yozora;
import ru.yozora.module.Module;

public class FpsBooster {
    private static final int TARGET_DELTA_MS = 4;

    private long lastFrame = System.nanoTime();
    private double smoothedFps = 0.0;
    private boolean boostActive = true;

    public void frame() {
        long now = System.nanoTime();
        double dt = (now - lastFrame) / 1_000_000.0;
        lastFrame = now;
        double fps = dt > 0 ? 1000.0 / dt : 0;
        smoothedFps = smoothedFps * 0.9 + fps * 0.1;
        if (boostActive) applyOptimizations();
    }

    private void applyOptimizations() {
        for (Module m : Yozora.modules().byCategory(ru.yozora.module.Category.OPTIMIZATION)) {
            if (m.isEnabled()) m.onTick();
        }
    }

    public double smoothedFps() { return smoothedFps; }
    public boolean boostActive() { return boostActive; }
    public void setBoostActive(boolean b) { boostActive = b; }
}
