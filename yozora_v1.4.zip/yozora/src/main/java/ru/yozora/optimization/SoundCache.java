package ru.yozora.optimization;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SoundCache {
    private final Map<String, Boolean> loaded = new ConcurrentHashMap<>();

    public boolean isLoaded(String id) {
        return loaded.computeIfAbsent(id, k -> true);
    }

    public int size() { return loaded.size(); }
}
