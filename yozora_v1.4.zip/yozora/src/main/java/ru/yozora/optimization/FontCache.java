package ru.yozora.optimization;

import java.util.concurrent.ConcurrentHashMap;

public class FontCache {
    private final ConcurrentHashMap<String, Integer> widths = new ConcurrentHashMap<>();

    public int widthOf(String text, java.util.function.ToIntFunction<String> real) {
        return widths.computeIfAbsent(text, real);
    }

    public void clear() { widths.clear(); }
}
