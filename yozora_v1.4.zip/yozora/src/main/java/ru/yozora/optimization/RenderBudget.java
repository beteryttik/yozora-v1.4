package ru.yozora.optimization;

public class RenderBudget {
    private int particleBudget = 400;
    private int entityBudget = 128;

    public boolean particleAllowed(int spawnedThisFrame) {
        return spawnedThisFrame < particleBudget;
    }

    public boolean entityAllowed(int renderedThisFrame) {
        return renderedThisFrame < entityBudget;
    }

    public void setParticleBudget(int b) { particleBudget = Math.max(50, b); }
    public void setEntityBudget(int b) { entityBudget = Math.max(16, b); }
}
