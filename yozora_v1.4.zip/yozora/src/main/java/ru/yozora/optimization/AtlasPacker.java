package ru.yozora.optimization;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class AtlasPacker {
    public static class Slot {
        public final BufferedImage image;
        public final int x, y;

        public Slot(BufferedImage image, int x, int y) {
            this.image = image;
            this.x = x;
            this.y = y;
        }
    }

    private final List<Slot> slots = new ArrayList<>();
    private int cursorX, cursorY, rowHeight, atlasWidth;

    public AtlasPacker(int atlasWidth) { this.atlasWidth = atlasWidth; }

    public void add(BufferedImage img) {
        if (cursorX + img.getWidth() > atlasWidth) {
            cursorX = 0;
            cursorY += rowHeight;
            rowHeight = 0;
        }
        slots.add(new Slot(img, cursorX, cursorY));
        cursorX += img.getWidth();
        rowHeight = Math.max(rowHeight, img.getHeight());
    }

    public List<Slot> slots() { return slots; }
    public int atlasHeight() { return cursorY + rowHeight; }
}
