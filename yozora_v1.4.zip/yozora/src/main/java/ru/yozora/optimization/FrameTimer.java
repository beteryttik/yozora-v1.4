package ru.yozora.optimization;

public class FrameTimer {
    private final long[] samples = new long[128];
    private int index;

    public void sample(long nanos) {
        samples[index] = nanos;
        index = (index + 1) % samples.length;
    }

    public double averageFps() {
        double sum = 0;
        int n = 0;
        for (long s : samples) {
            if (s > 0) { sum += s; n++; }
        }
        return n == 0 ? 0 : n * 1_000_000_000.0 / sum;
    }
}
