package ru.yozora.optimization;

import java.util.LinkedHashMap;
import java.util.Map;

public class ChunkCache<K, V> extends LinkedHashMap<K, V> {
    private final int maxSize;

    public ChunkCache(int maxSize) {
        super(64, 0.75f, true);
        this.maxSize = maxSize;
    }

    @Override
    protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
        return size() > maxSize;
    }
}
