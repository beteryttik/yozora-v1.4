package ru.yozora.gui.theme;

public interface YozoraTheme {
    String name();
    int panelColor();
    int cardColor();
    int cardHover();
    int sidebarColor();
    int accent();
    int enabled();
    int disabled();
    int selectedCard();
    int iconPlate();
    float guiScale();
    float blurRadius();
    void drawBlur(net.minecraft.client.gui.DrawContext ctx, int w, int h, float radius);
}
