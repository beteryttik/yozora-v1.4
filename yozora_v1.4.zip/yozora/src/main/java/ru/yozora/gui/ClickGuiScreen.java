package ru.yozora.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import ru.yozora.Yozora;
import ru.yozora.gui.theme.YozoraTheme;
import ru.yozora.gui.widget.ModuleCard;

public class ClickGuiScreen extends Screen {
    public static final int TAB_MODS = 0, TAB_SETTINGS = 1, TAB_COSMETICS = 2, TAB_CONFIGS = 3;

    private final TabBar tabBar = new TabBar();
    private final Sidebar sidebar = new Sidebar();
    private final ModsPanel modsPanel = new ModsPanel();
    private final SettingsPanel settingsPanel = new SettingsPanel();
    private final CosmeticsPanel cosmeticsPanel = new CosmeticsPanel();
    private final ConfigsPanel configsPanel = new ConfigsPanel();
    private int currentTab = TAB_MODS;
    private long openTime = System.currentTimeMillis();
    private float openAnimation = 0.0f;

    public ClickGuiScreen() {
        super(Text.literal("Yozora"));
    }

    @Override
    protected void init() {
        openTime = System.currentTimeMillis();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        YozoraTheme theme = Yozora.themes().current();
        float scale = theme.guiScale();
        int w = (int) (this.width / scale);
        ctx.getMatrices().push();
        ctx.getMatrices().translate((this.width - w) / 2f, 24, 0);
        ctx.getMatrices().scale(scale, scale, 1);
        ctx.fill(0, 0, w, this.height - 48, theme.panelColor());
        theme.drawBlur(ctx, w, this.height - 48, theme.blurRadius());
        tabBar.render(ctx, w, currentTab, theme);
        sidebar.render(ctx, w, currentTab, theme);
        switch (currentTab) {
            case TAB_MODS -> modsPanel.render(ctx, w, this.height, mouseX, mouseY, theme);
            case TAB_SETTINGS -> settingsPanel.render(ctx, w, this.height, mouseX, mouseY, theme);
            case TAB_COSMETICS -> cosmeticsPanel.render(ctx, w, this.height, mouseX, mouseY, theme);
            case TAB_CONFIGS -> configsPanel.render(ctx, w, this.height, mouseX, mouseY, theme);
        }
        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return tabBar.handleClick(mouseX, mouseY, button, this) || super.mouseClicked(mouseX, mouseY, button);
    }

    public void switchTab(int tab) {
        this.currentTab = tab;
    }

    public int currentTab() {
        return currentTab;
    }
}
