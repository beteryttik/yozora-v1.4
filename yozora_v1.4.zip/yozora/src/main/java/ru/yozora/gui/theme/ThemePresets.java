package ru.yozora.gui.theme;

public final class ThemePresets {
    private ThemePresets() {}

    public static YozoraTheme byName(String name) {
        return switch (name) {
            case "Lunar Blue" -> new SimpleTheme("Lunar Blue", 0xE6121418, 0xFF1D1D26, 0xFF26262F, 0xFF17171F, 0xFF3B82F6, 0xFF22C55E, 0xFFEF4444, 0xFF2A3A55, 0xFF20202A, 1.0f, 5.0f);
            case "Sakura Pink" -> new SimpleTheme("Sakura Pink", 0xE6161218, 0xFF221A22, 0xFF2D242D, 0xFF1C161C, 0xFFF472B6, 0xFF34D399, 0xFFEF4444, 0xFF3A2538, 0xFF2A202A, 1.0f, 6.0f);
            case "Midnight Neon" -> new SimpleTheme("Midnight Neon", 0xE60C0C10, 0xFF181820, 0xFF222230, 0xFF101018, 0xFF22D3EE, 0xFF4ADE80, 0xFFF87171, 0xFF1F2A38, 0xFF1C1C26, 1.0f, 4.0f);
            case "Forest" -> new SimpleTheme("Forest", 0xE6101812, 0xFF1A241C, 0xFF243026, 0xFF141C16, 0xFF4ADE80, 0xFF86EFAC, 0xFFF87171, 0xFF24382A, 0xFF1E2A20, 1.0f, 5.0f);
            default -> new SimpleTheme("Sakura Pink", 0xE6161218, 0xFF221A22, 0xFF2D242D, 0xFF1C161C, 0xFFF472B6, 0xFF34D399, 0xFFEF4444, 0xFF3A2538, 0xFF2A202A, 1.0f, 6.0f);
        };
    }

    private record SimpleTheme(String name, int panel, int card, int cardHover, int sidebar,
                               int accent, int enabled, int disabled, int selectedCard, int iconPlate,
                               float guiScale, float blurRadius) implements YozoraTheme {
        @Override public int panelColor() { return panel; }
        @Override public int cardColor() { return card; }
        @Override public int cardHover() { return cardHover; }
        @Override public int sidebarColor() { return sidebar; }
        @Override public int accent() { return accent; }
        @Override public int enabled() { return enabled; }
        @Override public int disabled() { return disabled; }
        @Override public int selectedCard() { return selectedCard; }
        @Override public int iconPlate() { return iconPlate; }
        @Override public float guiScale() { return guiScale; }
        @Override public float blurRadius() { return blurRadius; }
        @Override public void drawBlur(net.minecraft.client.gui.DrawContext ctx, int w, int h, float radius) {
            // blur is applied by BlurUtil post-processor
        }
    }
}
