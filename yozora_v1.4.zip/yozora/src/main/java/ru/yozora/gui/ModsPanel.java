package ru.yozora.gui;

import net.minecraft.client.gui.DrawContext;
import ru.yozora.Yozora;
import ru.yozora.gui.theme.YozoraTheme;
import ru.yozora.gui.widget.ModuleCard;
import ru.yozora.module.Category;
import ru.yozora.module.Module;

import java.util.ArrayList;
import java.util.List;

public class ModsPanel {
    private Category filter = null;
    private String search = "";
    private final List<ModuleCard> cards = new ArrayList<>();

    public void setFilter(Category filter) { this.filter = filter; }
    public void setSearch(String search) { this.search = search == null ? "" : search.toLowerCase(); }

    public void render(DrawContext ctx, int panelWidth, int panelHeight, int mx, int my, YozoraTheme theme) {
        // filter chips
        int cx = 220, cy = 52;
        String[] labels = {"ALL", "HUD", "VISUAL", "OPTIMIZATION", "UTILITIES"};
        for (int i = 0; i < labels.length; i++) {
            boolean active = (filter == null && i == 0) || (filter != null && filter.label().equalsIgnoreCase(labels[i]));
            ctx.fill(cx, cy, cx + 92, cy + 24, active ? theme.accent() : theme.cardColor());
            ctx.drawText(YozoraClient.minecraftTextRenderer(), labels[i], cx + 12, cy + 8, active ? 0xFFFFFFFF : 0xFFAAAAAA, false);
            cx += 100;
        }
        // cards
        List<Module> modules = filtered();
        int col = 0, row = 0;
        int cardW = 200, cardH = 150, gap = 12;
        for (Module m : modules) {
            int x = 220 + col * (cardW + gap);
            int y = 90 + row * (cardH + gap);
            ModuleCard card = new ModuleCard(m, x, y, cardW, cardH);
            card.render(ctx, theme, mx, my);
            cards.add(card);
            col++;
            if (col >= 3) { col = 0; row++; }
            if (row > 3) break;
        }
        cards.clear();
    }

    private List<Module> filtered() {
        List<Module> out = new ArrayList<>();
        for (Module m : Yozora.modules().all()) {
            if (filter != null && m.category() != filter) continue;
            if (!search.isEmpty() && !m.name().contains(search)) continue;
            out.add(m);
        }
        return out;
    }
}
