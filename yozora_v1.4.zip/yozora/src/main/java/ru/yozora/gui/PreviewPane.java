package ru.yozora.gui;

import net.minecraft.client.gui.DrawContext;
import ru.yozora.cosmetic.Cosmetic;
import ru.yozora.gui.theme.YozoraTheme;

public class PreviewPane {
    private float rotation;

    public void render(DrawContext ctx, int x, int y, Cosmetic selected, YozoraTheme theme) {
        ctx.fill(x, y, x + 200, y + 240, theme.sidebarColor());
        ctx.drawText(YozoraClient.minecraftTextRenderer(), "PREVIEW", x + 12, y + 10, 0xFFBBBBBB, false);
        if (selected == null) return;
        rotation += 0.02f;
        int px = x + 60 + (int) (Math.cos(rotation) * 20);
        ctx.drawTexture(selected.texture(), px, y + 60, 0, 0, 80, 40, 80, 40);
        ctx.drawText(YozoraClient.minecraftTextRenderer(), "DRAG TO ROTATE", x + 60, y + 150, 0xFF777777, false);
        ctx.drawText(YozoraClient.minecraftTextRenderer(), selected.name().toUpperCase(), x + 12, y + 170, 0xFFFFFFFF, false);
        ctx.drawText(YozoraClient.minecraftTextRenderer(), selected.description(), x + 12, y + 186, 0xFF909098, false);
    }
}
