package ru.yozora.gui;

import net.minecraft.client.gui.DrawContext;
import ru.yozora.Yozora;
import ru.yozora.cosmetic.CosmeticType;
import ru.yozora.gui.theme.YozoraTheme;

public class CosmeticsPanel {
    private CosmeticType filter = CosmeticType.ALL;

    public void setFilter(CosmeticType filter) { this.filter = filter; }

    public void render(DrawContext ctx, int panelWidth, int panelHeight, int mx, int my, YozoraTheme theme) {
        int x = 220, y = 52;
        ctx.drawText(YozoraClient.minecraftTextRenderer(), "COSMETICS", x, y, 0xFFFFFFFF, false);
        ctx.drawText(YozoraClient.minecraftTextRenderer(), "Yozora cosmetic collection", x, y + 12, 0xFF909098, false);
        y += 30;
        int col = 0, row = 0;
        for (var c : Yozora.cosmetics().filtered(filter)) {
            int cx = x + col * 214, cy = y + row * 120;
            ctx.fill(cx, cy, cx + 200, cy + 110, theme.cardColor());
            ctx.drawTexture(c.texture(), cx + 60, cy + 12, 0, 0, 80, 40, 80, 40);
            ctx.drawText(YozoraClient.minecraftTextRenderer(), c.name(), cx + 12, cy + 86, 0xFFEEEEEE, false);
            col++;
            if (col >= 2) { col = 0; row++; }
            if (row > 3) break;
        }
        // preview pane with drag-to-rotate is rendered by PreviewPane
    }
}
