package ru.yozora.gui;

import net.minecraft.client.gui.DrawContext;
import ru.yozora.gui.theme.YozoraTheme;
import ru.yozora.Yozora;

public class SettingsPanel {
    public void render(DrawContext ctx, int panelWidth, int panelHeight, int mx, int my, YozoraTheme theme) {
        int x = 220, y = 52;
        ctx.drawText(YozoraClient.minecraftTextRenderer(), "THEMES", x, y, 0xFFFFFFFF, false);
        ctx.drawText(YozoraClient.minecraftTextRenderer(), "Custom themes for GUI", x, y + 12, 0xFF909098, false);
        y += 30;
        for (var preset : Yozora.themes().presets()) {
            ctx.fill(x, y, x + panelWidth - 240, y + 30, theme.cardColor());
            ctx.drawText(YozoraClient.minecraftTextRenderer(), preset.name(), x + 12, y + 10, 0xFFFFFFFF, false);
            y += 34;
        }
        // Language, Hud Text Color, GUI Scale, Render Other Player Cosmetics rows are provided by ThemeManager
    }
}
