package ru.yozora.gui.widget;

import net.minecraft.client.gui.DrawContext;
import ru.yozora.gui.theme.YozoraTheme;
import ru.yozora.module.Module;

public class ModuleCard {
    private final Module module;
    private final int x, y, w, h;

    public ModuleCard(Module module, int x, int y, int w, int h) {
        this.module = module;
        this.x = x; this.y = y; this.w = w; this.h = h;
    }

    public void render(DrawContext ctx, YozoraTheme theme, int mx, int my) {
        boolean hovered = mx >= x && mx <= x + w && my >= y && my <= y + h;
        ctx.fill(x, y, x + w, y + h, hovered ? theme.cardHover() : theme.cardColor());
        // icon placeholder
        ctx.fill(x + w / 2 - 14, y + 14, x + w / 2 + 14, y + 42, theme.iconPlate());
        ctx.drawText(YozoraClient.minecraftTextRenderer(), module.name(), x + 12, y + 52, 0xFFFFFFFF, false);
        ctx.drawText(YozoraClient.minecraftTextRenderer(), "OPTIONS", x + 12, y + 74, 0xFFAAAAAA, false);
        // status bar
        int statusColor = module.isEnabled() ? theme.enabled() : theme.disabled();
        ctx.fill(x + 10, y + h - 30, x + w - 10, y + h - 14, statusColor);
        ctx.drawText(YozoraClient.minecraftTextRenderer(), module.isEnabled() ? "ENABLED" : "DISABLED",
                x + 20, y + h - 27, 0xFFFFFFFF, false);
    }

    public boolean isOver(double mx, double my) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    public Module module() {
        return module;
    }
}
