package ru.yozora.gui;

import net.minecraft.client.gui.DrawContext;
import ru.yozora.Yozora;

public class HudManager {
    public void renderAll(DrawContext ctx, float delta) {
        for (var m : Yozora.modules().enabled()) {
            if (m.category() == ru.yozora.module.Category.HUD) m.onRender(ctx, delta);
        }
    }
}
