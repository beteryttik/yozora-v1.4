package ru.yozora.gui;

import net.minecraft.client.gui.DrawContext;
import ru.yozora.gui.theme.YozoraTheme;

public class Sidebar {
    public void render(DrawContext ctx, int panelWidth, int currentTab, YozoraTheme theme) {
        if (currentTab == ClickGuiScreen.TAB_CONFIGS) return;
        ctx.fill(12, 44, 200, 260, theme.sidebarColor());
        // config chips, NEW CONFIG and EDIT HUD LAYOUT are drawn by ConfigPanel
    }
}
