package ru.yozora.gui;

import net.minecraft.client.gui.DrawContext;
import ru.yozora.Yozora;
import ru.yozora.gui.theme.YozoraTheme;

public class ConfigsPanel {
    public void render(DrawContext ctx, int panelWidth, int panelHeight, int mx, int my, YozoraTheme theme) {
        int y = 52;
        for (var c : Yozora.configs().all()) {
            ctx.fill(220, y, 220 + panelWidth - 260, y + 60, c.active() ? theme.selectedCard() : theme.cardColor());
            ctx.drawText(YozoraClient.minecraftTextRenderer(), c.timestamp(), 240, y + 10, 0xFF888888, false);
            ctx.drawText(YozoraClient.minecraftTextRenderer(), c.name() + " · " + c.owner(), 240, y + 24, 0xFFFFFFFF, false);
            ctx.drawText(YozoraClient.minecraftTextRenderer(), "Size: " + c.sizeKb() + " KB   Last modified: " + c.agoText(), 240, y + 40, 0xFF909098, false);
            y += 68;
        }
    }
}
