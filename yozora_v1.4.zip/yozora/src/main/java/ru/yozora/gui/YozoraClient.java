package ru.yozora.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;

public final class YozoraClient {
    private YozoraClient() {}

    public static TextRenderer minecraftTextRenderer() {
        return MinecraftClient.getInstance().textRenderer;
    }

    public static int textWidth(String s) {
        return minecraftTextRenderer().getWidth(s);
    }
}
