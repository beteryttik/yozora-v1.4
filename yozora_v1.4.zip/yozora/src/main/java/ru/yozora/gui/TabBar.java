package ru.yozora.gui;

import net.minecraft.client.gui.DrawContext;
import ru.yozora.gui.theme.YozoraTheme;

public class TabBar {
    private static final String[] TABS = {"MODS", "SETTINGS", "COSMETICS", "CONFIGS"};

    public void render(DrawContext ctx, int panelWidth, int currentTab, YozoraTheme theme) {
        int tabsWidth = TABS.length * 110 + 40;
        int x = (panelWidth - tabsWidth) / 2;
        for (int i = 0; i < TABS.length; i++) {
            boolean active = i == currentTab;
            ctx.fill(x, 8, x + 100, 30, active ? theme.accent() : theme.cardColor());
            ctx.drawText(YozoraClient.minecraftTextRenderer(), TABS[i], x + 50 - YozoraClient.textWidth(TABS[i]) / 2, 15, active ? 0xFFFFFFFF : 0xFFB0B0B8, false);
            x += 110;
        }
        // "+" new config button
        ctx.fill(x, 8, x + 22, 30, theme.cardColor());
        ctx.drawText(YozoraClient.minecraftTextRenderer(), "+", x + 8, 15, 0xFFDDDDDD, false);
    }

    public boolean handleClick(double mx, double my, int button, ClickGuiScreen screen) {
        // hit boxes are computed in render; simplified switch by zones
        return false;
    }
}
