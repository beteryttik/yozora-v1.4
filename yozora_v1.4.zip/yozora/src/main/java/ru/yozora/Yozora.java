package ru.yozora;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.yozora.cosmetic.CosmeticManager;
import ru.yozora.config.ConfigManager;
import ru.yozora.config.ThemeManager;
import ru.yozora.gui.HudManager;
import ru.yozora.module.ModuleManager;
import ru.yozora.optimization.FpsBooster;
import ru.yozora.util.NotificationManager;

public class Yozora implements ModInitializer {
    public static final String MOD_ID = "yozora";
    public static final Logger LOGGER = LoggerFactory.getLogger("Yozora");
    private static ModuleManager modules;
    private static CosmeticManager cosmetics;
    private static HudManager hud;
    private static ConfigManager configs;
    private static ThemeManager themes;
    private static NotificationManager notifications;
    private static FpsBooster fpsBooster;

    @Override
    public void onInitialize() {
        long start = System.currentTimeMillis();
        LOGGER.info("[Yozora] initializing...");
        themes = new ThemeManager();
        themes.loadThemes();
        configs = new ConfigManager();
        configs.loadDefault();
        modules = new ModuleManager();
        modules.registerAll();
        cosmetics = new CosmeticManager();
        cosmetics.load();
        hud = new HudManager();
        notifications = new NotificationManager();
        fpsBooster = new FpsBooster();
        LOGGER.info("[Yozora] ready in {} ms: {} modules, {} cosmetics",
                System.currentTimeMillis() - start, modules.count(), cosmetics.count());
    }

    public static ModuleManager modules() { return modules; }
    public static CosmeticManager cosmetics() { return cosmetics; }
    public static HudManager hud() { return hud; }
    public static ConfigManager configs() { return configs; }
    public static ThemeManager themes() { return themes; }
    public static NotificationManager notifications() { return notifications; }
    public static FpsBooster fpsBooster() { return fpsBooster; }
}
