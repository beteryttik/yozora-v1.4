package ru.yozora.command;

public class YozoraCommand {
    public static void register() {
        // /yozora gui|modules|cosmetics|configs|fps
    }
}
