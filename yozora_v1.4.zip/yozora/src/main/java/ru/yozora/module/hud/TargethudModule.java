package ru.yozora.module.hud;

import ru.yozora.module.Module;
import ru.yozora.module.Category;
import ru.yozora.module.setting.BooleanSetting;
import ru.yozora.module.setting.SliderSetting;

public class TargethudModule extends Module {
    public TargethudModule() {
        super("targethud", "Target health and name", Category.HUD);
        addSettings(
            new BooleanSetting("Show in HUD", true),
            new SliderSetting("Opacity", 1.0, 0.1, 1.0, 0.05)
        );
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void onTick() {
    }
}
