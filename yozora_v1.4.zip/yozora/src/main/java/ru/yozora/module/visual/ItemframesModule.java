package ru.yozora.module.visual;

import ru.yozora.module.Module;
import ru.yozora.module.Category;
import ru.yozora.module.setting.BooleanSetting;
import ru.yozora.module.setting.SliderSetting;

public class ItemframesModule extends Module {
    public ItemframesModule() {
        super("itemframes", "Cleaner item frame rendering", Category.VISUAL);
        addSettings(
            new BooleanSetting("Show in HUD", false),
            new SliderSetting("Opacity", 1.0, 0.1, 1.0, 0.05)
        );
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void onTick() {
    }
}
