package ru.yozora.module.setting;

import java.util.List;

public class ModeSetting extends Setting {
    private final List<String> modes;
    private int index;

    public ModeSetting(String name, List<String> modes, int index) {
        super(name);
        this.modes = modes;
        this.index = index;
    }

    public String get() { return modes.get(index); }
    public void next() { index = (index + 1) % modes.size(); }
    public void prev() { index = (index - 1 + modes.size()) % modes.size(); }
    public List<String> modes() { return modes; }

    @Override
    public String display() { return get(); }
}
