package ru.yozora.module.setting;

public class SliderSetting extends Setting {
    private double value, min, max, step;

    public SliderSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double get() { return value; }
    public void set(double v) { value = Math.max(min, Math.min(max, v)); }
    public double min() { return min; }
    public double max() { return max; }
    public double step() { return step; }

    @Override
    public String display() { return String.format("%.1f", value); }
}
