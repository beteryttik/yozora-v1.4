package ru.yozora.module;

public abstract class Module {
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private final ru.yozora.module.setting.SettingRegistry settings = new ru.yozora.module.setting.SettingRegistry();

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected void addSettings(ru.yozora.module.setting.Setting... list) {
        for (ru.yozora.module.setting.Setting s : list) settings.add(s);
    }

    public String name() { return name; }
    public String description() { return description; }
    public Category category() { return category; }
    public ru.yozora.module.setting.SettingRegistry settings() { return settings; }
    public boolean isEnabled() { return enabled; }

    public void toggle() {
        if (enabled) disable(); else enable();
    }

    public void enable() {
        enabled = true;
        onEnable();
    }

    public void disable() {
        enabled = false;
        onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    public void onRender(net.minecraft.client.gui.DrawContext ctx, float delta) {}
}
