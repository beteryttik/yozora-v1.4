package ru.yozora.module;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void registerAll() {
        modules.addAll(ru.yozora.module.Modules.all());
        modules.sort(Comparator.comparing(Module::name));
    }

    public List<Module> all() {
        return modules;
    }

    public int count() {
        return modules.size();
    }

    public Optional<Module> byName(String name) {
        return modules.stream().filter(m -> m.name().equalsIgnoreCase(name)).findFirst();
    }

    public List<Module> byCategory(Category category) {
        return modules.stream().filter(m -> m.category() == category).toList();
    }

    public List<Module> enabled() {
        return modules.stream().filter(Module::isEnabled).toList();
    }
}
