package ru.yozora.module.setting;

public abstract class Setting {
    private final String name;
    protected Setting(String name) { this.name = name; }
    public String name() { return name; }
    public abstract String display();
}
