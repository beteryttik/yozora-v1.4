package ru.yozora.module.setting;

public class ColorSetting extends Setting {
    private int rgba;

    public ColorSetting(String name, int rgba) {
        super(name);
        this.rgba = rgba;
    }

    public int get() { return rgba; }
    public void set(int rgba) { this.rgba = rgba; }
    public int red() { return (rgba >> 16) & 0xFF; }
    public int green() { return (rgba >> 8) & 0xFF; }
    public int blue() { return rgba & 0xFF; }
    public int alpha() { return (rgba >> 24) & 0xFF; }

    @Override
    public String display() { return String.format("#%06X", rgba & 0xFFFFFF); }
}
