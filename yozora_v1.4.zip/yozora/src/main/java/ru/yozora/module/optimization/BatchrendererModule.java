package ru.yozora.module.optimization;

import ru.yozora.module.Module;
import ru.yozora.module.Category;
import ru.yozora.module.setting.BooleanSetting;
import ru.yozora.module.setting.SliderSetting;

public class BatchrendererModule extends Module {
    public BatchrendererModule() {
        super("batchrenderer", "Batched rendering pipeline", Category.OPTIMIZATION);
        addSettings(
            new BooleanSetting("Show in HUD", true),
            new SliderSetting("Opacity", 1.0, 0.1, 1.0, 0.05)
        );
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void onTick() {
    }
}
