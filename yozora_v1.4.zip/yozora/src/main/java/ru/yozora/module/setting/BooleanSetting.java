package ru.yozora.module.setting;

public class BooleanSetting extends Setting {
    private boolean value;

    public BooleanSetting(String name, boolean value) {
        super(name);
        this.value = value;
    }

    public boolean get() { return value; }
    public void set(boolean v) { value = v; }
    public void flip() { value = !value; }

    @Override
    public String display() { return value ? "ON" : "OFF"; }
}
