package ru.yozora.module;

import java.util.ArrayList;
import java.util.List;

public final class Modules {
    private Modules() {}

    public static List<Module> all() {
        List<Module> list = new ArrayList<>();
        list.add(new ru.yozora.module.hud.FpsModule());
        list.add(new ru.yozora.module.hud.PingModule());
        list.add(new ru.yozora.module.hud.TpsModule());
        list.add(new ru.yozora.module.hud.CoordsModule());
        list.add(new ru.yozora.module.hud.DirectionModule());
        list.add(new ru.yozora.module.hud.ArmorhudModule());
        list.add(new ru.yozora.module.hud.PotionhudModule());
        list.add(new ru.yozora.module.hud.WatermarkModule());
        list.add(new ru.yozora.module.hud.KeystrokesModule());
        list.add(new ru.yozora.module.hud.CpsModule());
        list.add(new ru.yozora.module.hud.ServeripModule());
        list.add(new ru.yozora.module.hud.ClockModule());
        list.add(new ru.yozora.module.hud.ComboModule());
        list.add(new ru.yozora.module.hud.TargethudModule());
        list.add(new ru.yozora.module.hud.MemoryModule());
        list.add(new ru.yozora.module.hud.SpeedometerModule());
        list.add(new ru.yozora.module.hud.ArraylistModule());
        list.add(new ru.yozora.module.hud.NotificationsModule());
        list.add(new ru.yozora.module.hud.ScoreboardModule());
        list.add(new ru.yozora.module.hud.ChattimeModule());
        list.add(new ru.yozora.module.hud.HealthdisplayModule());
        list.add(new ru.yozora.module.hud.UsagehudModule());
        list.add(new ru.yozora.module.hud.BiomehudModule());
        list.add(new ru.yozora.module.hud.TotemhudModule());
        list.add(new ru.yozora.module.hud.ArrayspeedModule());
        list.add(new ru.yozora.module.visual.ZoomModule());
        list.add(new ru.yozora.module.visual.FullbrightModule());
        list.add(new ru.yozora.module.visual.NohurtcamModule());
        list.add(new ru.yozora.module.visual.CustomcrosshairModule());
        list.add(new ru.yozora.module.visual.CustomskycolorModule());
        list.add(new ru.yozora.module.visual.WorldparticlesModule());
        list.add(new ru.yozora.module.visual.AnimationsModule());
        list.add(new ru.yozora.module.visual.HitmarkersModule());
        list.add(new ru.yozora.module.visual.ClearwaterModule());
        list.add(new ru.yozora.module.visual.CustomfovModule());
        list.add(new ru.yozora.module.visual.ViewbobbingModule());
        list.add(new ru.yozora.module.visual.MotionblurModule());
        list.add(new ru.yozora.module.visual.BetterleavesModule());
        list.add(new ru.yozora.module.visual.NorenderbreakModule());
        list.add(new ru.yozora.module.visual.CustomskyModule());
        list.add(new ru.yozora.module.visual.RemovalsModule());
        list.add(new ru.yozora.module.visual.WeatherremoverModule());
        list.add(new ru.yozora.module.visual.VignetteModule());
        list.add(new ru.yozora.module.visual.ItemframesModule());
        list.add(new ru.yozora.module.visual.ElytravisualModule());
        list.add(new ru.yozora.module.visual.ArmorshadowModule());
        list.add(new ru.yozora.module.visual.SunsetboostModule());
        list.add(new ru.yozora.module.visual.StarsboostModule());
        list.add(new ru.yozora.module.visual.CloudboostModule());
        list.add(new ru.yozora.module.visual.BlockoutlineModule());
        list.add(new ru.yozora.module.optimization.FpsboostModule());
        list.add(new ru.yozora.module.optimization.EntitycullingModule());
        list.add(new ru.yozora.module.optimization.ParticlelimiterModule());
        list.add(new ru.yozora.module.optimization.LightoptimizerModule());
        list.add(new ru.yozora.module.optimization.ChunkpreloaderModule());
        list.add(new ru.yozora.module.optimization.FastrenderModule());
        list.add(new ru.yozora.module.optimization.MemorytrimModule());
        list.add(new ru.yozora.module.optimization.NoscreenlagModule());
        list.add(new ru.yozora.module.optimization.CachemanagerModule());
        list.add(new ru.yozora.module.optimization.BatchrendererModule());
        list.add(new ru.yozora.module.optimization.SmartunloadingModule());
        list.add(new ru.yozora.module.optimization.SoundcacheModule());
        list.add(new ru.yozora.module.optimization.FontcacheModule());
        list.add(new ru.yozora.module.optimization.TextureatlasModule());
        list.add(new ru.yozora.module.optimization.BackgroundthrottleModule());
        list.add(new ru.yozora.module.utilities.SafewalkModule());
        list.add(new ru.yozora.module.utilities.AutosprintModule());
        list.add(new ru.yozora.module.utilities.AutoggModule());
        list.add(new ru.yozora.module.utilities.AutoeatModule());
        list.add(new ru.yozora.module.utilities.ChatfilterModule());
        list.add(new ru.yozora.module.utilities.FriendsModule());
        list.add(new ru.yozora.module.utilities.WaypointsModule());
        list.add(new ru.yozora.module.utilities.AutotoolModule());
        list.add(new ru.yozora.module.utilities.MiddclickpearlModule());
        list.add(new ru.yozora.module.utilities.ScreenshottoolModule());
        return list;
    }
}
