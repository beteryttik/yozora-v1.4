package ru.yozora.module;

public enum Category {
    HUD("hud"),
    VISUAL("visual"),
    OPTIMIZATION("optimization"),
    UTILITIES("utilities");

    private final String key;

    Category(String key) { this.key = key; }

    public String key() { return key; }
    public String label() {
        return switch (this) {
            case HUD -> "HUD";
            case VISUAL -> "Visual";
            case OPTIMIZATION -> "Optimization";
            case UTILITIES -> "Utilities";
        };
    }
}
