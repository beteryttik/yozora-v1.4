package ru.yozora.module.hud;

import ru.yozora.module.Module;
import ru.yozora.module.Category;
import ru.yozora.module.setting.BooleanSetting;
import ru.yozora.module.setting.SliderSetting;

public class ClockModule extends Module {
    public ClockModule() {
        super("clock", "Local time widget", Category.HUD);
        addSettings(
            new BooleanSetting("Show in HUD", false),
            new SliderSetting("Opacity", 1.0, 0.1, 1.0, 0.05)
        );
    }

    @Override
    protected void onEnable() {
    }

    @Override
    protected void onDisable() {
    }

    @Override
    public void onTick() {
    }
}
