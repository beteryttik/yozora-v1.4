package ru.yozora.module.setting;

import java.util.ArrayList;
import java.util.List;

public class SettingRegistry {
    private final List<Setting> settings = new ArrayList<>();

    public void add(Setting s) { settings.add(s); }
    public List<Setting> all() { return settings; }
    public int count() { return settings.size(); }
}
