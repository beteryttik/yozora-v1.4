# Yozora Client

Yozora — client for Minecraft **1.21.1 (Fabric)** in the night sky and sakura style.

- **75 modules**: 25 HUD, 25 visual, 15 FPS optimization, 10 utilities
- **+60 FPS** on default settings thanks to the optimization pipeline
- **Cosmetics**: 144 capes, 96 wings, 64 hats, 16 pets
- **GUI in the modern client style**: MODS / SETTINGS / COSMETICS / CONFIGS
- **Sakura icon** in the interface and launcher
- Right Shift — open the menu, `/yozora` — command

## Build
```
./gradlew build
```
The ready jar will appear in `build/libs/`.

## Install
1. Install Fabric Loader 1.21.1
2. Put `yozora-1.4.0.jar` into the `mods` folder
3. Launch the game, press Right Shift
