# Roadmap

- HUD layout editor
- More cosmetic presets
- Custom skins
