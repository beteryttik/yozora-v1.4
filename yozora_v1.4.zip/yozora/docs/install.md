# Installation

1. Fabric Loader
2. mods folder
3. Right Shift
