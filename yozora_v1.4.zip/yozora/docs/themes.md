# Themes

12 presets, blur radius, GUI scale.
