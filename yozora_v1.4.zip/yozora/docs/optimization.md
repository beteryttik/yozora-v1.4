# FPS optimization

The FpsBooster pipeline: culling, particles, caches, batching.
