# Cosmetics

144 capes, 96 wings, 64 hats, 16 pets. Preview with drag-to-rotate.
