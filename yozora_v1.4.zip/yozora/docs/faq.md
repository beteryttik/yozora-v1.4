# FAQ

Q: Where is the GUI? A: Right Shift.
