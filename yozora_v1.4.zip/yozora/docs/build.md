# Building

`./gradlew build`
