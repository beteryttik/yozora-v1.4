# Style

Colors: dark panel, rounded cards, status bars, accent color from the theme.
