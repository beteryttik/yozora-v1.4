# Keybinds

Right Shift — GUI. /yozora — command.
